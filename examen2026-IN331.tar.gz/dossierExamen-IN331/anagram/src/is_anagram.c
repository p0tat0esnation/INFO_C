#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "functions.h"


/* Check if two words are anagrams, case sensitively or not.
    @param word1 First word
    @param word2 Second word
    @param case_sensitive 1 for case sensitive, 0 for case insensitive
    @returns 1 if anagrams, 0 otherwise
*/
int is_anagram(const char *word1, const char *word2, int case_sensitive)
{
    return 0;
}