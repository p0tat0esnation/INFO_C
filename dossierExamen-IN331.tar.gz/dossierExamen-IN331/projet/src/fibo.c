#include "functions.h"

void fibonnacci(int n, int values[]){

}