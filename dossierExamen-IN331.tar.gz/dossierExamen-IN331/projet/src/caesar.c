#include "functions.h"

void caesarDecipher(char *str, int shift){
    return;
}
