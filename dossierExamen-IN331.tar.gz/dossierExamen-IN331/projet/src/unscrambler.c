#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#include "functions.h"

int extract_information(const char *input_file, char *message)
{
    message[0] = '\0';
    return 0;
}